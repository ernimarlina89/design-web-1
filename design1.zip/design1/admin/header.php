<header>
        <div class="row">
            <div class="col-2">
                <h2>ADMINISTRATOR</h2>
            </div>
            
            <div class="col-7">
                <h4>APLIKASI WEB ONLINE</h4>
                <p>Jl. Nusa Indah No. 112 Denpasar</p>
            </div>

            <div class="col-3">
                <div class="box3">
                    <h3>Hi Admin!</h3>
                </div>
            </div>
        </div>
    </header>