 <ul>
                        <li><a href="">MENU 1</a></li>
                        <li><a href="">MENU 2</a></li>
                        <li><a href="">MENU 3</a></li>
                        <li><a href="">MENU 4</a></li>
                        <li><a href="">MENU 5</a></li>
                        <li><a href="">MENU 6</a></li>
                        <li><a href="">MENU 7</a></li>
                    </ul>