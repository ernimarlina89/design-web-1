<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ADMIN</title>
    <link rel="stylesheet" href="asset/style.css">
    <link rel="stylesheet" href="asset/aos-master/dist/aos.css">
</head>
<body>
    <!-- header -->
        <?php include "header.php" ?>
    <!-- batas header -->



<!-- isi -->
    <div class="row">
        <!-- sidebar -->
            <div class="col-2">
                <aside>
                   <?php include "sidebar.php" ?>
                </aside>
            </div>
        <!-- batas sidebar -->

        <!-- konten -->
            <div class="col-10" data-aos="fade-down" ata-aos-easing="linear" data-aos-duration="900">  
                <section>
                    <h3>Beranda</h3>
                    <hr>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Hic animi veniam quaerat cupiditate quo quae dolorem excepturi quam qui. Eos necessitatibus animi facilis tenetur ipsum, placeat eum rem ratione tempore.</p>

                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reiciendis dolor obcaecati deserunt officia sed ullam ex molestiae distinctio eaque nobis ut provident non quibusdam temporibus cumque magnam praesentium, consectetur esse!</p>

                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi molestias, distinctio vero saepe assumenda error excepturi perferendis, qui ullam iure architecto blanditiis, ea nam earum commodi? Accusantium quam ut consequatur?</p>
                </section>
            </div>
        <!-- batas konten -->
    </div>
<!-- batas isi -->

<!-- footer -->
<footer>
    <h4>&copy; 2019 | All Right Deserved</h4>

</footer>
<!-- batas footer -->

<script src="asset/aos-master/dist/aos.js"></script>
    <script>
      AOS.init({
        easing: 'ease-in-out-sine'
      });
    </script>
</body>
</html>